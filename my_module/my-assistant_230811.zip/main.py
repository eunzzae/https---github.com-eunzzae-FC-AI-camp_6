import speech_recognition as sr
from tts import speak
from naver import *
from weather import *
from gtts import gTTS 
from playsound import playsound

def call_JiNi():
    print("인식 중...")
    query = takeCommand()
    print(f'{query}\n')
    if query == '지니':
        speak('네')
    else:
        speak('다시 말씀해주세요.')

# 듣는 기능                
def takeCommand():
    r = sr.Recognizer()
    with sr.Microphone() as source:
        print("듣는 중...")
        audio = r.listen(source, timeout=10, phrase_time_limit=5)
    try:
        print("인식 중...")
        query = r.recognize_google(audio, language = "ko-KR")
        print(f'{query}\n')
        
    except Exception as e:
        print("에러 발생")
        return ""
    return query
            
# 대답하는 기능 
if __name__ == "__main__":
    call_JiNi()
    while True:
        try:
            query = takeCommand()
            print(f'{query}\n')
            if '검색' in query:
                speak("무엇을 검색하시겠습니까?")
                query = takeCommand()
                keyword = query
                search_naver(keyword)
                
                query = takeCommand()
                print(f'{query}\n')
            elif '날씨' in query :
                speak("궁금한 위치를 말씀해주세요.")
                query = takeCommand()
                location = query
                weather_sta(location)
                
                query = takeCommand()
                print(f'{query}\n')
            elif '기온' in query :
                speak("궁금한 위치를 말씀해주세요.")
                query = takeCommand()
                location = query
                weather_temp(location)
            
                query = takeCommand()
                print(f'{query}\n')
            elif '미세먼지' in query:
                speak("궁금한 위치를 말씀해주세요.")
                query = takeCommand()
                location = query
                weather_air

        except sr.UnknownValueError:
            print("음성 인식 실패")
        except sr.RequestError:
            print("서버 에러 발생")
        except sr.WaitTimeoutError:
            print("인식 실패")



