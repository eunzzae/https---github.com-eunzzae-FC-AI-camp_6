from gtts import gTTS 
from playsound import playsound
import os

# 소리내기(tts)
def speak(text):
    print('[지니]', text)
    file_name = 'voice.mp3'
    tts = gTTS(text=text, lang='ko')
    tts.save(file_name)
    playsound(file_name)
    if os.path.exists(file_name): # voice.mp3 파일 삭제
        os.remove(file_name)
    return text


if __name__ == "__main__":
    text = 'ㅇ'
    speak(text)

